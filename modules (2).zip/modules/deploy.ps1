az deployment group create --name Deployment --resource-group Devopstraining --template-file modules/FEVM.bicep 
#   --parameters storageAccountType=Standard_GRS